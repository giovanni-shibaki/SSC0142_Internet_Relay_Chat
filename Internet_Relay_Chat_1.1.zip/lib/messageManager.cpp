/**
 * @file massageManager.cpp
 * @author 11796444 - Giovanni Shibaki Camargo
 * @author 11796472 - Lucas Keiti Anbo Mihara
 * @author 11795589 - Vitor Caetano Brustolin
 * @brief
 * @version 0.1
 * @date 2022-06-04
 *
 * @copyright Copyright (c) 2022
 *
 */

#include <iostream>
#include <string>
#include <queue>

using namespace std;

class massageManager
{
private:
    /* data */

public:
    massageManager(/* args */)
    {
    }

    /*~massageManager()
    {
    }*/
};
